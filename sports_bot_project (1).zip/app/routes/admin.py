from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_required, current_user
from ..models.match import Match
from ..extensions import db

admin_bp = Blueprint("admin", __name__)

def is_admin():
    return current_user.is_authenticated and current_user.is_admin

@admin_bp.route("/admin")
@login_required
def dashboard():
    if not is_admin():
        return "403"
    matches = Match.query.all()
    return render_template("dashboard.html", matches=matches)

@admin_bp.route("/admin/add", methods=["POST"])
@login_required
def add():
    if not is_admin():
        return "403"
    m = Match(team_a=request.form["team_a"],
              team_b=request.form["team_b"],
              stadium=request.form["stadium"])
    db.session.add(m)
    db.session.commit()
    return redirect(url_for("admin.dashboard"))
