from ..extensions import db
from datetime import datetime

class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    team_a = db.Column(db.String(100))
    team_b = db.Column(db.String(100))
    stadium = db.Column(db.String(100))
    match_time = db.Column(db.DateTime, default=datetime.utcnow)
    is_posted = db.Column(db.Boolean, default=False)
