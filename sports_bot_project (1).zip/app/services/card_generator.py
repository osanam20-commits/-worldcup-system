from PIL import Image, ImageDraw

def generate_match_card(a,b,stadium,mid):
    img = Image.new("RGB",(800,800),(20,20,30))
    d = ImageDraw.Draw(img)
    d.text((50,100),"MATCH DAY",(255,255,255))
    d.text((50,300),a,(255,255,255))
    d.text((50,400),"VS",(255,200,0))
    d.text((50,500),b,(255,255,255))
    d.text((50,650),stadium,(180,180,180))

    path = f"/mnt/data/match_{mid}.png"
    img.save(path)
    return path
