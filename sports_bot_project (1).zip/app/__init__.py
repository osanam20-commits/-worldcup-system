from flask import Flask
from .extensions import db, login_manager
from werkzeug.security import generate_password_hash
from .models.user import User

def create_app():
    app = Flask(__name__)
    app.config.from_object("config.Config")

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .routes.auth import auth_bp
    from .routes.admin import admin_bp
    from .routes.main import main_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(main_bp)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    with app.app_context():
        db.create_all()

        admin = User.query.filter_by(username="admin").first()
        if not admin:
            admin = User(username="admin",
                         password=generate_password_hash("admin123"),
                         is_admin=True)
            db.session.add(admin)
            db.session.commit()

    return app
