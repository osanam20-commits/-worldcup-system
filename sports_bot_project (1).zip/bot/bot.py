import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from app import create_app
from app.models.match import Match

flask_app = create_app()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bot ready")

async def latest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with flask_app.app_context():
        m = Match.query.order_by(Match.id.desc()).first()
        if not m:
            await update.message.reply_text("No matches")
            return
        await update.message.reply_text(f"{m.team_a} vs {m.team_b}")

def run_bot(token):
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("latest", latest))
    app.run_polling()
