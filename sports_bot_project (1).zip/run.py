import os
from threading import Thread
from app import create_app
from bot.bot import run_bot
from scheduler.start import start_scheduler

app = create_app()
TOKEN = os.environ.get("BOT_TOKEN", "PUT_TOKEN")

def start_bot():
    run_bot(TOKEN)

if __name__ == "__main__":
    Thread(target=start_bot).start()
    start_scheduler()
    app.run(host="0.0.0.0", port=5000, debug=False)
