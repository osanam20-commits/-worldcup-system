from app import create_app
from app.models.match import Match
from app.services.card_generator import generate_match_card
from telegram import Bot
import os

app = create_app()
bot = Bot(os.environ.get("BOT_TOKEN","x"))

def post_matches():
    with app.app_context():
        matches = Match.query.filter_by(is_posted=False).all()
        for m in matches:
            img = generate_match_card(m.team_a,m.team_b,m.stadium,m.id)
            try:
                with open(img,"rb") as f:
                    bot.send_photo("@your_channel",f,caption="Match")
                m.is_posted=True
            except:
                pass
        from app.extensions import db
        db.session.commit()
