from apscheduler.schedulers.background import BackgroundScheduler
from scheduler.jobs import post_matches

def start_scheduler():
    s = BackgroundScheduler()
    s.add_job(post_matches,"interval",seconds=60)
    s.start()
